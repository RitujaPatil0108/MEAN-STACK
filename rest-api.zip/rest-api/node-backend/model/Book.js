// Creating schema of the project
const mongoose = require('mongoose');
const schema = mongoose.Schema;
let Book = new schema({
    name:{
        type:String
    },
    price:{
        type:Number
    },
    description:{
        type:String
    },
    image:{
        type:String
    }
},
{
        collection:'books'
})

// Exporting module
module.exports = mongoose.model('Book', Book)