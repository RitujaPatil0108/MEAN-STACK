// Database Connection Code
    let express = require('express'),
    path = require('path'),
    mongoose = require('mongoose'),
    cors = require('cors'),
    bodyParser = require('body-parser'),
    mongoDb = require('./database/db');

// ADDED CODE ==================================================

var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://0.0.0.0:27017";

MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("bookstore");
    var query2 = {price:1,_id:0};
    var query1 = {  };
    var query3 = {price:1};
    
    dbo.collection("books").find(query1,query2).sort(query3).toArray(function(err, result) {
      if (err) throw err;
      console.log(result);
      db.close();
    });
  });

// ADDED CODE ==================================================

// Database connection

mongoose.Promise = global.Promise;
mongoose.connect(mongoDb.db, {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log("Database Successfully Connected!")
},
    error => {
        console.log("Database Connection Error: " + error)
    })

// Now Creating Server and Port
const bookRoute = require("./node-backend/routes/book.routes");
const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: false
}));

app.use(cors());


// PORT Creation
const port = process.env.port || 4000;
app.listen(port, () => {
    console.log("Listening Port On: " + port);
});

//API Root
app.use('/books', bookRoute);

// BaseRoute Creation
app.get('/',(req,res)=>{
    res.send("Invalid Endpoint");
})


// app.get('*',(req,res)=>{
//     res.sendFile(path.join(__dirname, 'dist/Bookstore/index.html'));
// });

app.use(function(err, req, res, next){
    console.log(err.message);
    if(!err.statusCode) err.statusCode = 500;
    res.status(err.statusCode).send(err.message);
})