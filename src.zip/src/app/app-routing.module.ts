import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AddBookComponent } from './components/add-book/add-book.component';
import { BookDetailsComponent } from './components/book-details/book-details.component';
import { BooksAboutComponent } from './components/books-about/books-about/books-about.component';
import { BooksListComponent } from './components/books-list/books-list.component';

const routes: Routes = [
  {
    path: '', redirectTo:'adminLogin', pathMatch:'full'
  },
  {
    path:'books-list', component:BooksListComponent
  },
  {
    path: 'add-book', component:AddBookComponent
  },
  {
    path:'edit-book/:id', component: BookDetailsComponent
  },
  {
    path:'admin-login', component: AdminLoginComponent
  },
  {
    path:'books-about', component: BooksAboutComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
