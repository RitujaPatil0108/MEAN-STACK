import { Component, OnInit, NgZone } from '@angular/core';
import { CrudService } from 'src/app/service/crud.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-books-list',
  templateUrl: './books-list.component.html',
  styleUrls: ['./books-list.component.css']
})

export class BooksListComponent implements OnInit 
{
  num = 1;
  Books:any = []
  constructor(private crudApi:CrudService, private ngZone: NgZone, private router:Router) { }

  ngOnInit(): void {
    this.crudApi.getBooks().subscribe(res=>{
      console.log(res);
      this.Books = res;
    })
  }

  delete(id:any, i:any){
    console.log(id);
    if(window.confirm('Are you sure, you want to delete?')){
      console.log("Confirmation recieved");
      this.crudApi.deleteBook(id).subscribe(res=>{
        for(let j=0;j<this.Books.length;j++)
        {
          if(this.Books[j]._id===res.msg._id)
          {
            i=j;
            break;
          }
        }
        this.Books.splice(i, 1);
      }),
      this.ngZone.run(()=>{
        this.router.navigateByUrl('/books-list')
      },(err:any) => {
        console.log(err);
      })
      // this.ngZone.ru
      this.num=(this.num+1)%2;
      ngDoCheck();
    }
  }

}

function ngDoCheck() 
{
  console.log("Deleted Data");
}
