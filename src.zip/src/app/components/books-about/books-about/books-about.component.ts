import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-books-about',
  templateUrl: './books-about.component.html',
  styleUrls: ['./books-about.component.css']
})
export class BooksAboutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
