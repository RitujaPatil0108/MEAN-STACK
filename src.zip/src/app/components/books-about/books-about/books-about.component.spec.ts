import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BooksAboutComponent } from './books-about.component';

describe('BooksAboutComponent', () => {
  let component: BooksAboutComponent;
  let fixture: ComponentFixture<BooksAboutComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BooksAboutComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BooksAboutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
