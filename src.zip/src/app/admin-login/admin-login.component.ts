import { Component, NgZone, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { CrudService } from 'src/app/service/crud.service';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {

  public userid = '';
  public password = ''; 
  constructor(private router:Router, private ngZone:NgZone, ) 
  {
   }

  ngOnInit(): void {
  }

  onsubmit():any{
    if(this.userid=="admin" && this.password=="admin@12345")
    {
      this.ngZone.run(()=>{
        this.router.navigateByUrl('/books-list')
      })
    }
}
}
