export class Book {
    _id!: String;
    name!: String;
    price!: number;
    description!: String;
    image!: String;
}
