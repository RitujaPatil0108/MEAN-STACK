import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { Book } from './book';
import { catchError, map} from 'rxjs/operators'

@Injectable({
  providedIn: 'root'
})
export class CrudService {

  // NodeJs API link
  REST_API = "http://localhost:4000/books";

  //Set http Headers
  httpHeaders = new HttpHeaders().set('Content-Type','application/json')
  constructor(private http:HttpClient) { }

  // add records
  AddBook(data:Book):Observable<any>{
    let API_URL = `${this.REST_API}/add-book`;
    return this.http.post(API_URL,data).pipe(catchError(this.handleError))
  }

  // get all records
  getBooks(){
    return this.http.get(`${this.REST_API}`);
  }

  // get single book
  getBook(id:any): Observable<any>{
    let API_URL = `${this.REST_API}/read-book/${id}`;
    return this.http.get(API_URL,{headers:this.httpHeaders}).pipe(map((res:any)=>{
      return res || {}
    }),
    catchError(this.handleError)
    )
  }

  // Update Book Data
  updateBook(id:any, data:any): Observable<any>{
    let API_URL = `${this.REST_API}/update-book/${id}`;
    return this.http.put(API_URL, data, {headers:this.httpHeaders}).pipe(catchError(this.handleError))
  }

  // Deleting Book Data
  deleteBook(id:any): Observable<any>{
    let API_URL = `${this.REST_API}/delete-book/${id}`;
    return this.http.get(API_URL, {headers: this.httpHeaders}).pipe(catchError(this.handleError))
  }

  // Error
  handleError(error: HttpErrorResponse){
    let errorMessage = '';
    if(error.error instanceof ErrorEvent){
      //Handle Client Error
      errorMessage = error.error.message;
    }
    else{
      // Handle Server Error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    console.log(errorMessage);
    return throwError(errorMessage);
  }

}

